# TradingPath

Full-stack prototype (backend + frontend) for TradingPath.

## Backend
- Node + Express + better-sqlite3
- API: /signup, /login, /notes

## Frontend
- Vite + React
- Simple UI to create and list notes

## Quick start
1. Start backend:
   ```
   cd backend
   npm install
   node index.js
   ```
2. Start frontend:
   ```
   cd frontend
   npm install
   npm run dev
   ```

Push this folder to a GitHub repo to host the project.
