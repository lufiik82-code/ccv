# TradingPath - Frontend

A minimal React + Vite frontend.

## Run
```
cd frontend
npm install
npm run dev
```
By default it expects the backend at http://localhost:4000. Set VITE_API_URL to change.
