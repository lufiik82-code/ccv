const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

// Signup (prototype: stores username+password plainly)
app.post('/signup', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({error:'username and password required'});
  try {
    const stmt = db.prepare('INSERT INTO users (username,password,created_at) VALUES (?,?,?)');
    stmt.run(username, password, Date.now());
    return res.json({ok:true, username});
  } catch (e) {
    return res.status(400).json({error: 'username taken'});
  }
});

// Login (prototype: no hashing)
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({error:'username and password required'});
  const row = db.prepare('SELECT * FROM users WHERE username = ? AND password = ?').get(username, password);
  if (!row) return res.status(401).json({error:'invalid credentials'});
  return res.json({ok:true, username: row.username});
});

// Create note
app.post('/notes', (req, res) => {
  const {
    owner, type, name, description, reason, feeling, ca, pnl, link, friends
  } = req.body;
  if (!owner || !type || !name) return res.status(400).json({error:'owner, type, name required'});
  const stmt = db.prepare('INSERT INTO notes (owner,type,name,description,reason,feeling,ca,pnl,link,friends,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
  const info = stmt.run(owner, type, name, description||'', reason||'', feeling||'', ca||'', pnl||'', link||'', (Array.isArray(friends)?friends.join(','):friends||''), Date.now());
  const id = info.lastInsertRowid;
  const note = db.prepare('SELECT * FROM notes WHERE id = ?').get(id);
  return res.json({ok:true, note});
});

// Get notes (optionally filter by owner)
app.get('/notes', (req, res) => {
  const owner = req.query.owner;
  let rows;
  if (owner) {
    rows = db.prepare('SELECT * FROM notes WHERE owner = ? ORDER BY created_at DESC').all(owner);
  } else {
    rows = db.prepare('SELECT * FROM notes ORDER BY created_at DESC LIMIT 500').all();
  }
  return res.json(rows);
});

// Simple health
app.get('/health', (req, res) => res.json({ok:true, time: Date.now()}));

app.listen(PORT, () => console.log('TradingPath backend listening on port', PORT));
