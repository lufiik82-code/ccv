const Database = require('better-sqlite3');
const db = new Database('tradingpath.db');

// users table: id (integer), username (unique), password (plain text for prototype)
db.prepare(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  password TEXT,
  created_at INTEGER
)`).run();

// notes table
db.prepare(`CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner TEXT,
  type TEXT, -- 'private' or 'group'
  name TEXT,
  description TEXT,
  reason TEXT,
  feeling TEXT,
  ca TEXT,
  pnl TEXT,
  link TEXT,
  friends TEXT, -- comma-separated invited friends
  created_at INTEGER
)`).run();

module.exports = db;
