# TradingPath - Backend

Prototype backend for TradingPath. Minimal, file-based SQLite storage using better-sqlite3.

## Run
```
cd backend
npm install
node index.js
```
The API will be available at http://localhost:4000
